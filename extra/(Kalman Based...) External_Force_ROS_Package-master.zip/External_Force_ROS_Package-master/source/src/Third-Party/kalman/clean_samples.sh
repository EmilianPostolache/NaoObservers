cd samples

cd KVector
make clean
cd ..

cd KMatrix
make clean
cd ..

cd EKFilter
make clean
cd ..

cd Example
make clean
cd ..

cd ..

